import pandas as pd

df_ser = pd.read_csv("2024-05-23-mio.csv")[["Fungen 1_frequency", "Lockin_amplitude", "Lockin_phase"]].rename(
    {"Fungen 1_frequency": "SER Frequency", "Lockin_amplitude": "SER Amplitude", "Lockin_phase": "SER Phase"}, axis="columns"
)
df_ser["SER Amplitude"] = df_ser["SER Amplitude"] * 1000000
df_lab = pd.read_csv("Viejo Sistema/2024-05-23", delimiter="\t",
                     names=["LAB Frequency", "LAB Amplitude", "LAB Phase", "Unk1", "Unk2", "unk3"])[[
    "LAB Frequency", "LAB Amplitude", "LAB Phase"]]

df = pd.concat([df_ser, df_lab], axis="columns")
df.plot()
